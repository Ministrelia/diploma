export const tail = (arr = []) => arr[arr.length - 1] || null;
