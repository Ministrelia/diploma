export const ANSWER = 'ANSWER';
export const GET_QUESTIONS = 'GET_QUESTIONS';
