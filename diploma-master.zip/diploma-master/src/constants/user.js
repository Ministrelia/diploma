export const AUTH = 'AUTH';
export const ADD_RESULT = 'ADD_RESULT';

